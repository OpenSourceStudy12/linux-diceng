#undef LOCK
#define LOCK		L

#undef UNLOCK
#define UNLOCK		U

#undef RLOCK
#undef WLOCK

#undef INIT
#define INIT		SI
